﻿namespace OgrenciNotSistemi.forms
{
    partial class OgretmenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRaporlar = new System.Windows.Forms.Button();
            this.btnOgrencileriGoruntule = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnQuestion = new System.Windows.Forms.PictureBox();
            this.btnWebSitesi = new System.Windows.Forms.PictureBox();
            this.btnInstagram = new System.Windows.Forms.PictureBox();
            this.btnImg = new System.Windows.Forms.PictureBox();
            this.lblBilgi = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.PictureBox();
            this.pnlOgrencileriGoruntule = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pnlNotGuncelle = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnYeniNotlar = new System.Windows.Forms.Button();
            this.lblOrtalama = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtFizikNot = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMatematikNot = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBiyolojiNot = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFelsefeNot = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTurkceNot = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblBiyolojiNot = new System.Windows.Forms.Label();
            this.lblFelsefeNot = new System.Windows.Forms.Label();
            this.lblFizikNot = new System.Windows.Forms.Label();
            this.lblMatematikNot = new System.Windows.Forms.Label();
            this.lblTurkceNot = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblOgrenciSifre = new System.Windows.Forms.Label();
            this.lblOgrenciNumara = new System.Windows.Forms.Label();
            this.lblOgrenciSoyad = new System.Windows.Forms.Label();
            this.lblOgrenciAd = new System.Windows.Forms.Label();
            this.lblOgrenciId = new System.Windows.Forms.Label();
            this.comboBoxStudents = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlRaporlar = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.lblBasarisizOgrenci = new System.Windows.Forms.Label();
            this.lnlBasariliOgrenci = new System.Windows.Forms.Label();
            this.lblToplamDers = new System.Windows.Forms.Label();
            this.lblToplamOgretmen = new System.Windows.Forms.Label();
            this.lblToplamOgrenci = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnQuestion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWebSitesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInstagram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.pnlOgrencileriGoruntule.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.pnlNotGuncelle.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlRaporlar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(96)))), ((int)(((byte)(200)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnRaporlar);
            this.panel1.Controls.Add(this.btnOgrencileriGoruntule);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.btnQuestion);
            this.panel1.Controls.Add(this.btnWebSitesi);
            this.panel1.Controls.Add(this.btnInstagram);
            this.panel1.Controls.Add(this.btnImg);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(276, 626);
            this.panel1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(13, 290);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 50);
            this.button1.TabIndex = 13;
            this.button1.Text = "Not Güncelleme";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRaporlar
            // 
            this.btnRaporlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnRaporlar.FlatAppearance.BorderSize = 0;
            this.btnRaporlar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRaporlar.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRaporlar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRaporlar.Location = new System.Drawing.Point(13, 348);
            this.btnRaporlar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRaporlar.Name = "btnRaporlar";
            this.btnRaporlar.Size = new System.Drawing.Size(249, 50);
            this.btnRaporlar.TabIndex = 12;
            this.btnRaporlar.Text = "Raporlar";
            this.btnRaporlar.UseVisualStyleBackColor = false;
            this.btnRaporlar.Click += new System.EventHandler(this.btnRaporlar_Click);
            // 
            // btnOgrencileriGoruntule
            // 
            this.btnOgrencileriGoruntule.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnOgrencileriGoruntule.FlatAppearance.BorderSize = 0;
            this.btnOgrencileriGoruntule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOgrencileriGoruntule.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrencileriGoruntule.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnOgrencileriGoruntule.Location = new System.Drawing.Point(13, 233);
            this.btnOgrencileriGoruntule.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnOgrencileriGoruntule.Name = "btnOgrencileriGoruntule";
            this.btnOgrencileriGoruntule.Size = new System.Drawing.Size(249, 50);
            this.btnOgrencileriGoruntule.TabIndex = 4;
            this.btnOgrencileriGoruntule.Text = "Öğrencileri Görüntüle";
            this.btnOgrencileriGoruntule.UseVisualStyleBackColor = false;
            this.btnOgrencileriGoruntule.Click += new System.EventHandler(this.btnOgrencileriGoruntule_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(223)))), ((int)(((byte)(239)))));
            this.label6.Location = new System.Drawing.Point(84, 158);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Cüneyt Öz";
            // 
            // btnQuestion
            // 
            this.btnQuestion.Image = global::OgrenciNotSistemi.Properties.Resources.question_mark;
            this.btnQuestion.Location = new System.Drawing.Point(16, 561);
            this.btnQuestion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnQuestion.Name = "btnQuestion";
            this.btnQuestion.Size = new System.Drawing.Size(43, 39);
            this.btnQuestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnQuestion.TabIndex = 6;
            this.btnQuestion.TabStop = false;
            // 
            // btnWebSitesi
            // 
            this.btnWebSitesi.Image = global::OgrenciNotSistemi.Properties.Resources.internet;
            this.btnWebSitesi.Location = new System.Drawing.Point(237, 571);
            this.btnWebSitesi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWebSitesi.Name = "btnWebSitesi";
            this.btnWebSitesi.Size = new System.Drawing.Size(32, 30);
            this.btnWebSitesi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnWebSitesi.TabIndex = 5;
            this.btnWebSitesi.TabStop = false;
            // 
            // btnInstagram
            // 
            this.btnInstagram.Image = global::OgrenciNotSistemi.Properties.Resources.instagram;
            this.btnInstagram.Location = new System.Drawing.Point(197, 571);
            this.btnInstagram.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInstagram.Name = "btnInstagram";
            this.btnInstagram.Size = new System.Drawing.Size(32, 30);
            this.btnInstagram.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnInstagram.TabIndex = 4;
            this.btnInstagram.TabStop = false;
            // 
            // btnImg
            // 
            this.btnImg.Image = global::OgrenciNotSistemi.Properties.Resources.icons8_teacher_100;
            this.btnImg.Location = new System.Drawing.Point(49, 37);
            this.btnImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnImg.Name = "btnImg";
            this.btnImg.Size = new System.Drawing.Size(184, 117);
            this.btnImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnImg.TabIndex = 0;
            this.btnImg.TabStop = false;
            // 
            // lblBilgi
            // 
            this.lblBilgi.AutoSize = true;
            this.lblBilgi.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBilgi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(223)))), ((int)(((byte)(239)))));
            this.lblBilgi.Location = new System.Drawing.Point(284, 37);
            this.lblBilgi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBilgi.Name = "lblBilgi";
            this.lblBilgi.Size = new System.Drawing.Size(248, 31);
            this.lblBilgi.TabIndex = 2;
            this.lblBilgi.Text = "Öğretmen Paneli";
            // 
            // btnClose
            // 
            this.btnClose.Image = global::OgrenciNotSistemi.Properties.Resources.cross;
            this.btnClose.Location = new System.Drawing.Point(947, 16);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(67, 31);
            this.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnClose.TabIndex = 2;
            this.btnClose.TabStop = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlOgrencileriGoruntule
            // 
            this.pnlOgrencileriGoruntule.Controls.Add(this.dataGridView1);
            this.pnlOgrencileriGoruntule.Location = new System.Drawing.Point(291, 87);
            this.pnlOgrencileriGoruntule.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlOgrencileriGoruntule.Name = "pnlOgrencileriGoruntule";
            this.pnlOgrencileriGoruntule.Size = new System.Drawing.Size(713, 529);
            this.pnlOgrencileriGoruntule.TabIndex = 4;
            this.pnlOgrencileriGoruntule.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(713, 529);
            this.dataGridView1.TabIndex = 0;
            // 
            // pnlNotGuncelle
            // 
            this.pnlNotGuncelle.Controls.Add(this.groupBox3);
            this.pnlNotGuncelle.Controls.Add(this.groupBox2);
            this.pnlNotGuncelle.Controls.Add(this.groupBox1);
            this.pnlNotGuncelle.Controls.Add(this.comboBoxStudents);
            this.pnlNotGuncelle.Controls.Add(this.label1);
            this.pnlNotGuncelle.Location = new System.Drawing.Point(291, 87);
            this.pnlNotGuncelle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlNotGuncelle.Name = "pnlNotGuncelle";
            this.pnlNotGuncelle.Size = new System.Drawing.Size(713, 529);
            this.pnlNotGuncelle.TabIndex = 1;
            this.pnlNotGuncelle.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnYeniNotlar);
            this.groupBox3.Controls.Add(this.lblOrtalama);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtFizikNot);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtMatematikNot);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtBiyolojiNot);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtFelsefeNot);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtTurkceNot);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(21, 319);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(659, 206);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Not Güncelle";
            // 
            // btnYeniNotlar
            // 
            this.btnYeniNotlar.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnYeniNotlar.FlatAppearance.BorderSize = 0;
            this.btnYeniNotlar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYeniNotlar.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYeniNotlar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnYeniNotlar.Location = new System.Drawing.Point(251, 150);
            this.btnYeniNotlar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnYeniNotlar.Name = "btnYeniNotlar";
            this.btnYeniNotlar.Size = new System.Drawing.Size(177, 43);
            this.btnYeniNotlar.TabIndex = 14;
            this.btnYeniNotlar.Text = "Not Güncelleme";
            this.btnYeniNotlar.UseVisualStyleBackColor = false;
            this.btnYeniNotlar.Click += new System.EventHandler(this.btnYeniNotlar_Click);
            // 
            // lblOrtalama
            // 
            this.lblOrtalama.AutoSize = true;
            this.lblOrtalama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblOrtalama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOrtalama.ForeColor = System.Drawing.Color.White;
            this.lblOrtalama.Location = new System.Drawing.Point(467, 102);
            this.lblOrtalama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrtalama.Name = "lblOrtalama";
            this.lblOrtalama.Size = new System.Drawing.Size(97, 20);
            this.lblOrtalama.TabIndex = 17;
            this.lblOrtalama.Text = "Ortalama: 0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(275, 102);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 16;
            this.label10.Text = "Fizik Notu:";
            // 
            // txtFizikNot
            // 
            this.txtFizikNot.Location = new System.Drawing.Point(368, 101);
            this.txtFizikNot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFizikNot.Name = "txtFizikNot";
            this.txtFizikNot.Size = new System.Drawing.Size(47, 22);
            this.txtFizikNot.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(13, 102);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Matematik Notu:";
            // 
            // txtMatematikNot
            // 
            this.txtMatematikNot.Location = new System.Drawing.Point(156, 100);
            this.txtMatematikNot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatematikNot.Name = "txtMatematikNot";
            this.txtMatematikNot.Size = new System.Drawing.Size(47, 22);
            this.txtMatematikNot.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(467, 42);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "Biyoloji Notu:";
            // 
            // txtBiyolojiNot
            // 
            this.txtBiyolojiNot.Location = new System.Drawing.Point(583, 39);
            this.txtBiyolojiNot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBiyolojiNot.Name = "txtBiyolojiNot";
            this.txtBiyolojiNot.Size = new System.Drawing.Size(47, 22);
            this.txtBiyolojiNot.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(247, 42);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Felsefe Notu:";
            // 
            // txtFelsefeNot
            // 
            this.txtFelsefeNot.Location = new System.Drawing.Point(364, 41);
            this.txtFelsefeNot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFelsefeNot.Name = "txtFelsefeNot";
            this.txtFelsefeNot.Size = new System.Drawing.Size(47, 22);
            this.txtFelsefeNot.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(13, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Türkçe Notu:";
            // 
            // txtTurkceNot
            // 
            this.txtTurkceNot.Location = new System.Drawing.Point(127, 41);
            this.txtTurkceNot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTurkceNot.Name = "txtTurkceNot";
            this.txtTurkceNot.Size = new System.Drawing.Size(47, 22);
            this.txtTurkceNot.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblBiyolojiNot);
            this.groupBox2.Controls.Add(this.lblFelsefeNot);
            this.groupBox2.Controls.Add(this.lblFizikNot);
            this.groupBox2.Controls.Add(this.lblMatematikNot);
            this.groupBox2.Controls.Add(this.lblTurkceNot);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(355, 100);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(325, 212);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Öğrenci Not Bilgileri";
            // 
            // lblBiyolojiNot
            // 
            this.lblBiyolojiNot.AutoSize = true;
            this.lblBiyolojiNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBiyolojiNot.ForeColor = System.Drawing.Color.White;
            this.lblBiyolojiNot.Location = new System.Drawing.Point(25, 159);
            this.lblBiyolojiNot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBiyolojiNot.Name = "lblBiyolojiNot";
            this.lblBiyolojiNot.Size = new System.Drawing.Size(178, 20);
            this.lblBiyolojiNot.TabIndex = 7;
            this.lblBiyolojiNot.Text = "Öğrenci Şifre: Mehmet";
            // 
            // lblFelsefeNot
            // 
            this.lblFelsefeNot.AutoSize = true;
            this.lblFelsefeNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFelsefeNot.ForeColor = System.Drawing.Color.White;
            this.lblFelsefeNot.Location = new System.Drawing.Point(25, 130);
            this.lblFelsefeNot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFelsefeNot.Name = "lblFelsefeNot";
            this.lblFelsefeNot.Size = new System.Drawing.Size(202, 20);
            this.lblFelsefeNot.TabIndex = 6;
            this.lblFelsefeNot.Text = "Öğrenci Numara: Mehmet";
            // 
            // lblFizikNot
            // 
            this.lblFizikNot.AutoSize = true;
            this.lblFizikNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFizikNot.ForeColor = System.Drawing.Color.White;
            this.lblFizikNot.Location = new System.Drawing.Point(25, 102);
            this.lblFizikNot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFizikNot.Name = "lblFizikNot";
            this.lblFizikNot.Size = new System.Drawing.Size(189, 20);
            this.lblFizikNot.TabIndex = 5;
            this.lblFizikNot.Text = "Öğrenci Soyad: Mehmet";
            // 
            // lblMatematikNot
            // 
            this.lblMatematikNot.AutoSize = true;
            this.lblMatematikNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMatematikNot.ForeColor = System.Drawing.Color.White;
            this.lblMatematikNot.Location = new System.Drawing.Point(25, 74);
            this.lblMatematikNot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatematikNot.Name = "lblMatematikNot";
            this.lblMatematikNot.Size = new System.Drawing.Size(163, 20);
            this.lblMatematikNot.TabIndex = 4;
            this.lblMatematikNot.Text = "Öğrenci Ad: Mehmet";
            // 
            // lblTurkceNot
            // 
            this.lblTurkceNot.AutoSize = true;
            this.lblTurkceNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTurkceNot.ForeColor = System.Drawing.Color.White;
            this.lblTurkceNot.Location = new System.Drawing.Point(25, 46);
            this.lblTurkceNot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTurkceNot.Name = "lblTurkceNot";
            this.lblTurkceNot.Size = new System.Drawing.Size(160, 20);
            this.lblTurkceNot.TabIndex = 3;
            this.lblTurkceNot.Text = "Öğrenci ID: Mehmet";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblOgrenciSifre);
            this.groupBox1.Controls.Add(this.lblOgrenciNumara);
            this.groupBox1.Controls.Add(this.lblOgrenciSoyad);
            this.groupBox1.Controls.Add(this.lblOgrenciAd);
            this.groupBox1.Controls.Add(this.lblOgrenciId);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(21, 100);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(325, 212);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Öğrenci Kişisel Bilgiler";
            // 
            // lblOgrenciSifre
            // 
            this.lblOgrenciSifre.AutoSize = true;
            this.lblOgrenciSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciSifre.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciSifre.Location = new System.Drawing.Point(25, 159);
            this.lblOgrenciSifre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOgrenciSifre.Name = "lblOgrenciSifre";
            this.lblOgrenciSifre.Size = new System.Drawing.Size(178, 20);
            this.lblOgrenciSifre.TabIndex = 7;
            this.lblOgrenciSifre.Text = "Öğrenci Şifre: Mehmet";
            // 
            // lblOgrenciNumara
            // 
            this.lblOgrenciNumara.AutoSize = true;
            this.lblOgrenciNumara.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciNumara.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciNumara.Location = new System.Drawing.Point(25, 130);
            this.lblOgrenciNumara.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOgrenciNumara.Name = "lblOgrenciNumara";
            this.lblOgrenciNumara.Size = new System.Drawing.Size(202, 20);
            this.lblOgrenciNumara.TabIndex = 6;
            this.lblOgrenciNumara.Text = "Öğrenci Numara: Mehmet";
            // 
            // lblOgrenciSoyad
            // 
            this.lblOgrenciSoyad.AutoSize = true;
            this.lblOgrenciSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciSoyad.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciSoyad.Location = new System.Drawing.Point(25, 102);
            this.lblOgrenciSoyad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOgrenciSoyad.Name = "lblOgrenciSoyad";
            this.lblOgrenciSoyad.Size = new System.Drawing.Size(189, 20);
            this.lblOgrenciSoyad.TabIndex = 5;
            this.lblOgrenciSoyad.Text = "Öğrenci Soyad: Mehmet";
            // 
            // lblOgrenciAd
            // 
            this.lblOgrenciAd.AutoSize = true;
            this.lblOgrenciAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciAd.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciAd.Location = new System.Drawing.Point(25, 74);
            this.lblOgrenciAd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOgrenciAd.Name = "lblOgrenciAd";
            this.lblOgrenciAd.Size = new System.Drawing.Size(163, 20);
            this.lblOgrenciAd.TabIndex = 4;
            this.lblOgrenciAd.Text = "Öğrenci Ad: Mehmet";
            // 
            // lblOgrenciId
            // 
            this.lblOgrenciId.AutoSize = true;
            this.lblOgrenciId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciId.ForeColor = System.Drawing.Color.White;
            this.lblOgrenciId.Location = new System.Drawing.Point(25, 46);
            this.lblOgrenciId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOgrenciId.Name = "lblOgrenciId";
            this.lblOgrenciId.Size = new System.Drawing.Size(160, 20);
            this.lblOgrenciId.TabIndex = 3;
            this.lblOgrenciId.Text = "Öğrenci ID: Mehmet";
            // 
            // comboBoxStudents
            // 
            this.comboBoxStudents.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxStudents.FormattingEnabled = true;
            this.comboBoxStudents.Location = new System.Drawing.Point(96, 37);
            this.comboBoxStudents.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxStudents.Name = "comboBoxStudents";
            this.comboBoxStudents.Size = new System.Drawing.Size(583, 28);
            this.comboBoxStudents.TabIndex = 1;
            this.comboBoxStudents.SelectedIndexChanged += new System.EventHandler(this.comboBoxStudents_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(17, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci:";
            // 
            // pnlRaporlar
            // 
            this.pnlRaporlar.Controls.Add(this.label16);
            this.pnlRaporlar.Controls.Add(this.lblBasarisizOgrenci);
            this.pnlRaporlar.Controls.Add(this.lnlBasariliOgrenci);
            this.pnlRaporlar.Controls.Add(this.lblToplamDers);
            this.pnlRaporlar.Controls.Add(this.lblToplamOgretmen);
            this.pnlRaporlar.Controls.Add(this.lblToplamOgrenci);
            this.pnlRaporlar.Controls.Add(this.label15);
            this.pnlRaporlar.Controls.Add(this.label14);
            this.pnlRaporlar.Controls.Add(this.label12);
            this.pnlRaporlar.Controls.Add(this.label11);
            this.pnlRaporlar.Location = new System.Drawing.Point(291, 87);
            this.pnlRaporlar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlRaporlar.Name = "pnlRaporlar";
            this.pnlRaporlar.Size = new System.Drawing.Size(713, 529);
            this.pnlRaporlar.TabIndex = 10;
            this.pnlRaporlar.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(61, 359);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(381, 31);
            this.label16.TabIndex = 6;
            this.label16.Text = "Matematikten Kalan Öğrenci";
            // 
            // lblBasarisizOgrenci
            // 
            this.lblBasarisizOgrenci.AutoSize = true;
            this.lblBasarisizOgrenci.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBasarisizOgrenci.Location = new System.Drawing.Point(479, 362);
            this.lblBasarisizOgrenci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBasarisizOgrenci.Name = "lblBasarisizOgrenci";
            this.lblBasarisizOgrenci.Size = new System.Drawing.Size(30, 31);
            this.lblBasarisizOgrenci.TabIndex = 5;
            this.lblBasarisizOgrenci.Text = "0";
            // 
            // lnlBasariliOgrenci
            // 
            this.lnlBasariliOgrenci.AutoSize = true;
            this.lnlBasariliOgrenci.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lnlBasariliOgrenci.Location = new System.Drawing.Point(479, 305);
            this.lnlBasariliOgrenci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lnlBasariliOgrenci.Name = "lnlBasariliOgrenci";
            this.lnlBasariliOgrenci.Size = new System.Drawing.Size(30, 31);
            this.lnlBasariliOgrenci.TabIndex = 5;
            this.lnlBasariliOgrenci.Text = "0";
            // 
            // lblToplamDers
            // 
            this.lblToplamDers.AutoSize = true;
            this.lblToplamDers.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamDers.Location = new System.Drawing.Point(479, 251);
            this.lblToplamDers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToplamDers.Name = "lblToplamDers";
            this.lblToplamDers.Size = new System.Drawing.Size(30, 31);
            this.lblToplamDers.TabIndex = 5;
            this.lblToplamDers.Text = "0";
            // 
            // lblToplamOgretmen
            // 
            this.lblToplamOgretmen.AutoSize = true;
            this.lblToplamOgretmen.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamOgretmen.Location = new System.Drawing.Point(479, 197);
            this.lblToplamOgretmen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToplamOgretmen.Name = "lblToplamOgretmen";
            this.lblToplamOgretmen.Size = new System.Drawing.Size(30, 31);
            this.lblToplamOgretmen.TabIndex = 5;
            this.lblToplamOgretmen.Text = "0";
            // 
            // lblToplamOgrenci
            // 
            this.lblToplamOgrenci.AutoSize = true;
            this.lblToplamOgrenci.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamOgrenci.Location = new System.Drawing.Point(479, 143);
            this.lblToplamOgrenci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToplamOgrenci.Name = "lblToplamOgrenci";
            this.lblToplamOgrenci.Size = new System.Drawing.Size(30, 31);
            this.lblToplamOgrenci.TabIndex = 5;
            this.lblToplamOgrenci.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(185, 251);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(267, 31);
            this.label15.TabIndex = 4;
            this.label15.Text = "Toplam Ders Sayısı";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(115, 197);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(333, 31);
            this.label14.TabIndex = 3;
            this.label14.Text = "Toplam Öğretmen Sayısı";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(51, 305);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(392, 31);
            this.label12.TabIndex = 1;
            this.label12.Text = "Matematikten Geçen Öğrenci";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(141, 143);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(307, 31);
            this.label11.TabIndex = 0;
            this.label11.Text = "Toplam Öğrenci Sayısı";
            // 
            // OgretmenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(154)))), ((int)(((byte)(222)))));
            this.ClientSize = new System.Drawing.Size(1016, 626);
            this.Controls.Add(this.pnlRaporlar);
            this.Controls.Add(this.pnlNotGuncelle);
            this.Controls.Add(this.pnlOgrencileriGoruntule);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblBilgi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "OgretmenForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OgretmenForm";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OgretmenForm_MouseDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnQuestion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWebSitesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInstagram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.pnlOgrencileriGoruntule.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.pnlNotGuncelle.ResumeLayout(false);
            this.pnlNotGuncelle.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlRaporlar.ResumeLayout(false);
            this.pnlRaporlar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox btnClose;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox btnQuestion;
        private System.Windows.Forms.PictureBox btnWebSitesi;
        private System.Windows.Forms.PictureBox btnInstagram;
        private System.Windows.Forms.Label lblBilgi;
        private System.Windows.Forms.PictureBox btnImg;
        private System.Windows.Forms.Button btnOgrencileriGoruntule;
        private System.Windows.Forms.Button btnRaporlar;
        private System.Windows.Forms.Panel pnlOgrencileriGoruntule;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel pnlNotGuncelle;
        private System.Windows.Forms.ComboBox comboBoxStudents;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblBiyolojiNot;
        private System.Windows.Forms.Label lblFelsefeNot;
        private System.Windows.Forms.Label lblFizikNot;
        private System.Windows.Forms.Label lblMatematikNot;
        private System.Windows.Forms.Label lblTurkceNot;
        private System.Windows.Forms.Label lblOgrenciSifre;
        private System.Windows.Forms.Label lblOgrenciNumara;
        private System.Windows.Forms.Label lblOgrenciSoyad;
        private System.Windows.Forms.Label lblOgrenciAd;
        private System.Windows.Forms.Label lblOgrenciId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFelsefeNot;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTurkceNot;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnYeniNotlar;
        private System.Windows.Forms.Label lblOrtalama;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtFizikNot;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMatematikNot;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBiyolojiNot;
        private System.Windows.Forms.Panel pnlRaporlar;
        private System.Windows.Forms.Label lblBasarisizOgrenci;
        private System.Windows.Forms.Label lnlBasariliOgrenci;
        private System.Windows.Forms.Label lblToplamDers;
        private System.Windows.Forms.Label lblToplamOgretmen;
        private System.Windows.Forms.Label lblToplamOgrenci;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
    }
}