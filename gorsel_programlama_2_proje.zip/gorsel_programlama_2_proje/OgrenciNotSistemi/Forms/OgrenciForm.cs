﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotSistemi.forms
{
    public partial class OgrenciForm : Form
    {
        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\OgrenciNotSistemiDB.mdb";

        public int ogrenciNo;
        public OgrenciForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void OgrenciForm_Load(object sender, EventArgs e)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM Ogrenciler WHERE Numara = @numara";

                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@numara", ogrenciNo);

                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lblOgrenciID.Text = reader["ID"].ToString();
                            lblOgrenciAd.Text = reader["Ad"].ToString();
                            lblOgrenciSoyad.Text = reader["Soyad"].ToString();
                            lblOgrenciNo.Text = reader["Numara"].ToString();
                            lblOgrenciSifre.Text = reader["Sifre"].ToString();
                            lblTurkceNot.Text = reader["TurkceNot"].ToString();
                            lblMatematikNot.Text = reader["MatematikNot"].ToString();
                            lblFelsefeNot.Text = reader["FelsefeNot"].ToString();
                            lblBiyolojiNot.Text = reader["BiyolojiNot"].ToString();
                            lblFizikNot.Text = reader["FizikNot"].ToString();
                        }
                    }
                }
            }
        }
    }
}
