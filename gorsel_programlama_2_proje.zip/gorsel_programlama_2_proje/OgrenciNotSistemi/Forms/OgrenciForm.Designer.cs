﻿namespace OgrenciNotSistemi.forms
{
    partial class OgrenciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblOgrenciID = new System.Windows.Forms.Label();
            this.lblOgrenciAd = new System.Windows.Forms.Label();
            this.lblOgrenciSoyad = new System.Windows.Forms.Label();
            this.lblOgrenciNo = new System.Windows.Forms.Label();
            this.lblOgrenciSifre = new System.Windows.Forms.Label();
            this.lblFizikNot = new System.Windows.Forms.Label();
            this.lblTurkceNot = new System.Windows.Forms.Label();
            this.lblMatematikNot = new System.Windows.Forms.Label();
            this.lblFelsefeNot = new System.Windows.Forms.Label();
            this.lblBiyolojiNot = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(100, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Öğrenci ID:";
            // 
            // btnClose
            // 
            this.btnClose.Image = global::OgrenciNotSistemi.Properties.Resources.cross;
            this.btnClose.Location = new System.Drawing.Point(423, 10);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 25);
            this.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnClose.TabIndex = 3;
            this.btnClose.TabStop = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(94, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Öğrenci Ad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(59, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Öğrenci Soyad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(45, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Öğrenci Numara:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(76, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Öğrenci Şifre:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(63, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Matematik Not:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(96, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "Türkçe Not:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(91, 388);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Felsefe Not:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(93, 427);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Biyoloji Not:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(117, 271);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 25);
            this.label10.TabIndex = 12;
            this.label10.Text = "Fizik Not:";
            // 
            // lblOgrenciID
            // 
            this.lblOgrenciID.AutoSize = true;
            this.lblOgrenciID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciID.Location = new System.Drawing.Point(218, 76);
            this.lblOgrenciID.Name = "lblOgrenciID";
            this.lblOgrenciID.Size = new System.Drawing.Size(24, 25);
            this.lblOgrenciID.TabIndex = 13;
            this.lblOgrenciID.Text = "0";
            // 
            // lblOgrenciAd
            // 
            this.lblOgrenciAd.AutoSize = true;
            this.lblOgrenciAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciAd.Location = new System.Drawing.Point(218, 115);
            this.lblOgrenciAd.Name = "lblOgrenciAd";
            this.lblOgrenciAd.Size = new System.Drawing.Size(24, 25);
            this.lblOgrenciAd.TabIndex = 13;
            this.lblOgrenciAd.Text = "0";
            // 
            // lblOgrenciSoyad
            // 
            this.lblOgrenciSoyad.AutoSize = true;
            this.lblOgrenciSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciSoyad.Location = new System.Drawing.Point(218, 154);
            this.lblOgrenciSoyad.Name = "lblOgrenciSoyad";
            this.lblOgrenciSoyad.Size = new System.Drawing.Size(24, 25);
            this.lblOgrenciSoyad.TabIndex = 13;
            this.lblOgrenciSoyad.Text = "0";
            // 
            // lblOgrenciNo
            // 
            this.lblOgrenciNo.AutoSize = true;
            this.lblOgrenciNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciNo.Location = new System.Drawing.Point(218, 193);
            this.lblOgrenciNo.Name = "lblOgrenciNo";
            this.lblOgrenciNo.Size = new System.Drawing.Size(24, 25);
            this.lblOgrenciNo.TabIndex = 13;
            this.lblOgrenciNo.Text = "0";
            // 
            // lblOgrenciSifre
            // 
            this.lblOgrenciSifre.AutoSize = true;
            this.lblOgrenciSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrenciSifre.Location = new System.Drawing.Point(218, 232);
            this.lblOgrenciSifre.Name = "lblOgrenciSifre";
            this.lblOgrenciSifre.Size = new System.Drawing.Size(24, 25);
            this.lblOgrenciSifre.TabIndex = 13;
            this.lblOgrenciSifre.Text = "0";
            // 
            // lblFizikNot
            // 
            this.lblFizikNot.AutoSize = true;
            this.lblFizikNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFizikNot.Location = new System.Drawing.Point(218, 271);
            this.lblFizikNot.Name = "lblFizikNot";
            this.lblFizikNot.Size = new System.Drawing.Size(24, 25);
            this.lblFizikNot.TabIndex = 13;
            this.lblFizikNot.Text = "0";
            // 
            // lblTurkceNot
            // 
            this.lblTurkceNot.AutoSize = true;
            this.lblTurkceNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTurkceNot.Location = new System.Drawing.Point(218, 310);
            this.lblTurkceNot.Name = "lblTurkceNot";
            this.lblTurkceNot.Size = new System.Drawing.Size(24, 25);
            this.lblTurkceNot.TabIndex = 13;
            this.lblTurkceNot.Text = "0";
            // 
            // lblMatematikNot
            // 
            this.lblMatematikNot.AutoSize = true;
            this.lblMatematikNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMatematikNot.Location = new System.Drawing.Point(218, 349);
            this.lblMatematikNot.Name = "lblMatematikNot";
            this.lblMatematikNot.Size = new System.Drawing.Size(24, 25);
            this.lblMatematikNot.TabIndex = 13;
            this.lblMatematikNot.Text = "0";
            // 
            // lblFelsefeNot
            // 
            this.lblFelsefeNot.AutoSize = true;
            this.lblFelsefeNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFelsefeNot.Location = new System.Drawing.Point(218, 388);
            this.lblFelsefeNot.Name = "lblFelsefeNot";
            this.lblFelsefeNot.Size = new System.Drawing.Size(24, 25);
            this.lblFelsefeNot.TabIndex = 13;
            this.lblFelsefeNot.Text = "0";
            // 
            // lblBiyolojiNot
            // 
            this.lblBiyolojiNot.AutoSize = true;
            this.lblBiyolojiNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBiyolojiNot.Location = new System.Drawing.Point(218, 427);
            this.lblBiyolojiNot.Name = "lblBiyolojiNot";
            this.lblBiyolojiNot.Size = new System.Drawing.Size(24, 25);
            this.lblBiyolojiNot.TabIndex = 13;
            this.lblBiyolojiNot.Text = "0";
            // 
            // OgrenciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(154)))), ((int)(((byte)(222)))));
            this.ClientSize = new System.Drawing.Size(484, 499);
            this.Controls.Add(this.lblBiyolojiNot);
            this.Controls.Add(this.lblFelsefeNot);
            this.Controls.Add(this.lblMatematikNot);
            this.Controls.Add(this.lblTurkceNot);
            this.Controls.Add(this.lblFizikNot);
            this.Controls.Add(this.lblOgrenciSifre);
            this.Controls.Add(this.lblOgrenciNo);
            this.Controls.Add(this.lblOgrenciSoyad);
            this.Controls.Add(this.lblOgrenciAd);
            this.Controls.Add(this.lblOgrenciID);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OgrenciForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OgrenciForm";
            this.Load += new System.EventHandler(this.OgrenciForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox btnClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblOgrenciID;
        private System.Windows.Forms.Label lblOgrenciAd;
        private System.Windows.Forms.Label lblOgrenciSoyad;
        private System.Windows.Forms.Label lblOgrenciNo;
        private System.Windows.Forms.Label lblOgrenciSifre;
        private System.Windows.Forms.Label lblFizikNot;
        private System.Windows.Forms.Label lblTurkceNot;
        private System.Windows.Forms.Label lblMatematikNot;
        private System.Windows.Forms.Label lblFelsefeNot;
        private System.Windows.Forms.Label lblBiyolojiNot;
    }
}