﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace OgrenciNotSistemi.forms
{
    public partial class OgretmenForm : Form
    {

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        private int ogrenciID;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();


        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\OgrenciNotSistemiDB.mdb";

        private void GetStudents()
        {
            pnlNotGuncelle.Visible = false;
            pnlRaporlar.Visible = false;
            pnlOgrencileriGoruntule.Visible = true;
            string query = "SELECT * FROM Ogrenciler";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, conn);

                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;

                    lblBilgi.Text = "Tüm Öğrenciler";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void UpdateGrades()
        {
            pnlOgrencileriGoruntule.Visible = false;
            pnlRaporlar.Visible = false;
            pnlNotGuncelle.Visible = true;

            string query = "SELECT * FROM Ogrenciler";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, conn))
                {
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    comboBoxStudents.DisplayMember = "Ad";
                    comboBoxStudents.ValueMember = "ID";
                    comboBoxStudents.DataSource = dataTable;
                }
            }

            lblBilgi.Text = "Not Güncelle";
        }
      
        private void ListData()
        {
            if (comboBoxStudents.SelectedItem != null)
            {
                DataRowView row = comboBoxStudents.SelectedItem as DataRowView;

                if (row != null)
                {
                    ogrenciID = Convert.ToInt32(row["ID"]);
                    lblOgrenciId.Text = "Öğrenci ID: " + row["ID"].ToString();
                    lblOgrenciAd.Text = "Öğrenci Ad: " + row["Ad"].ToString();
                    lblOgrenciSoyad.Text = "Öğrenci Soyad: " + row["Soyad"].ToString();
                    lblOgrenciNumara.Text = "Öğrenci Numara: " + row["Numara"].ToString();
                    lblOgrenciSifre.Text = "Öğrenci Şifre: " + row["Sifre"].ToString();

                    lblTurkceNot.Text = "Türkçe: " + row["TurkceNot"].ToString();
                    lblMatematikNot.Text = "Matematik: " + row["MatematikNot"].ToString();
                    lblFizikNot.Text = "Fizik: " + row["FizikNot"].ToString();
                    lblFelsefeNot.Text = "Felsefe: " + row["FelsefeNot"].ToString();
                    lblBiyolojiNot.Text = "Biyoloji: " + row["BiyolojiNot"].ToString();

                    txtTurkceNot.Text = row["TurkceNot"].ToString();
                    txtMatematikNot.Text = row["MatematikNot"].ToString();
                    txtFizikNot.Text = row["FizikNot"].ToString();
                    txtFelsefeNot.Text = row["FelsefeNot"].ToString();
                    txtBiyolojiNot.Text = row["BiyolojiNot"].ToString();

                    lblOrtalama.Text = "Ortalama: " +
                        ((Convert.ToDouble(row["TurkceNot"]) +
                        Convert.ToDouble(row["MatematikNot"]) +
                        Convert.ToDouble(row["FizikNot"]) +
                        Convert.ToDouble(row["FelsefeNot"]) +
                        Convert.ToDouble(row["BiyolojiNot"])) / 5).ToString("0.00");
                }
            }
          
        }

        private int GetCount(OleDbConnection cn, string query)
        {
            using (OleDbCommand cmd = new OleDbCommand(query, cn))
            {
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public OgretmenForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnOgrencileriGoruntule_Click(object sender, EventArgs e)
        {
            GetStudents();
        }

        private void OgretmenForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        private void comboBoxStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListData();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            UpdateGrades();
        }

        private void btnYeniNotlar_Click(object sender, EventArgs e)
        {
            int matematikNot = Convert.ToInt32(txtMatematikNot.Text);
            int turkceNot = Convert.ToInt32(txtTurkceNot.Text);
            int fizikNot = Convert.ToInt32(txtFizikNot.Text);
            int biyolojiNot = Convert.ToInt32(txtBiyolojiNot.Text);
            int felsefeNot = Convert.ToInt32(txtFelsefeNot.Text);

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = "UPDATE Ogrenciler SET MatematikNot = @matematikNot, TurkceNot = @turkceNot, FizikNot = @fizikNot, BiyolojiNot = @biyolojiNot, FelsefeNot = @felsefeNot WHERE ID = @id";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@matematikNot", matematikNot);
                        cmd.Parameters.AddWithValue("@turkceNot", turkceNot);
                        cmd.Parameters.AddWithValue("@fizikNot", fizikNot);
                        cmd.Parameters.AddWithValue("@biyolojiNot", biyolojiNot);
                        cmd.Parameters.AddWithValue("@felsefeNot", felsefeNot);
                        cmd.Parameters.AddWithValue("@id", ogrenciID);

                        int rowAffected = cmd.ExecuteNonQuery();

                        if (rowAffected > 0)
                        {
                            MessageBox.Show("Güncelleme başarılı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ListData();
                            GetStudents();
                        }
                        else
                        {
                            MessageBox.Show("Güncellenecek kayıt bulunamadı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message);
                }
            }
        }

        private void btnRaporlar_Click(object sender, EventArgs e)
        {
            pnlNotGuncelle.Visible = false;
            pnlOgrencileriGoruntule.Visible = false;
            pnlRaporlar.Visible = true;
            lblBilgi.Text = "Raporlar";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();

                int toplamOgrenciSayisi = GetCount(conn, "SELECT COUNT(*) FROM Ogrenciler");
                int toplamOgretmenSayisi = GetCount(conn, "SELECT COUNT(*) FROM Ogretmenler");
                int toplamDersSayisi = GetCount(conn, "SELECT COUNT(*) FROM Dersler");
                int matGecenOgrenciler = GetCount(conn, "SELECT COUNT(*) FROM Ogrenciler WHERE MatematikNot >= 50");
                int matKalanOgrenciler = GetCount(conn, "SELECT COUNT(*) FROM Ogrenciler WHERE MatematikNot < 50");

                lblToplamOgrenci.Text = toplamOgrenciSayisi.ToString();
                lblToplamOgretmen.Text = toplamOgretmenSayisi.ToString();
                lblToplamDers.Text = toplamDersSayisi.ToString();
                lnlBasariliOgrenci.Text = matGecenOgrenciler.ToString();
                lblBasarisizOgrenci.Text = matKalanOgrenciler.ToString();
            }
        }
    }
}

