﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OgrenciNotSistemi.forms;

namespace OgrenciNotSistemi
{
    public partial class Form1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();


        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\OgrenciNotSistemiDB.mdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Öğrencilerin notlarını görüntülediği, öğretmenlerin not bilgisini sisteme girdiği ve yöneticilerin her iki tarafıda kontrol ettiği bir Öğrenci Not Sistemi uygulaması.");
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.google.com/");
        }

        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text;
            string sifre = txtSifre.Text;
            string rol = "";

            if (kullaniciAdi != "" && sifre != "")
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    string queryString = "SELECT * FROM Ogrenciler WHERE Numara = @numara AND Sifre = @sifre";

                    using (OleDbCommand cmd = new OleDbCommand(queryString, conn))
                    {
                        cmd.Parameters.AddWithValue("@numara", kullaniciAdi);
                        cmd.Parameters.AddWithValue("@sifre", sifre);

                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                rol = "Öğrenci";
                                OgrenciForm ogr = new OgrenciForm();
                                ogr.ogrenciNo = Convert.ToInt32(kullaniciAdi);
                                this.Hide();
                                ogr.ShowDialog();
                            }
                        }
                    }

                    if (rol == "")
                    {
                        string queryOgretmen = "SELECT * FROM Ogretmenler WHERE KullaniciAdi = @kullaniciAdi AND Sifre = @sifre";

                        using (OleDbCommand cmd = new OleDbCommand(queryOgretmen, conn))
                        {
                            cmd.Parameters.AddWithValue("@kullaniciAdi", kullaniciAdi);
                            cmd.Parameters.AddWithValue("@sifre", sifre);

                            using (OleDbDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    rol = "Öğretmen";
                                    OgretmenForm ogr = new OgretmenForm();
                                    this.Hide();
                                    ogr.ShowDialog();
                                }
                            }
                        }
                    }
                }

                if (rol == "")
                {
                    MessageBox.Show("Kullanıcı bulunamadı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Boş alan bırakılamaz", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtKullaniciAdi;
        }
    }
}
